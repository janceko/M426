import unittest
from main import Player, NormalState, StrongState, MagicalState, AttackStrategy, TacticalStrategy, MagicStrategy

class TestPlayer(unittest.TestCase):
    def test_initial_attributes(self):
        player = Player("TestPlayer")
        self.assertEqual(player.attributes["mut"], 50)
        self.assertEqual(player.attributes["klugheit"], 50)
        self.assertEqual(player.attributes["stärke"], 50)
        self.assertEqual(player.attributes["magie"], 50)

    def test_set_state(self):
        player = Player("TestPlayer")
        normal_state = NormalState()
        player.set_state(normal_state)
        self.assertEqual(player.current_state, normal_state)
        self.assertEqual(player.attributes["mut"], 50)  # Mut sollte unverändert sein

        strong_state = StrongState()
        player.set_state(strong_state)
        self.assertEqual(player.current_state, strong_state)
        self.assertEqual(player.attributes["mut"], 60)  # Mut sollte nun auf 60 geändert sein

    def test_execute_strategy(self):
        player = Player("TestPlayer")
        attack_strategy = AttackStrategy()
        player.set_strategy(attack_strategy)
        player.execute_strategy()
        self.assertEqual(player.attributes["mut"], 70)  # Mut sollte um 20 erhöht sein
        self.assertEqual(player.attributes["stärke"], 60)  # Stärke sollte um 10 erhöht sein

        tactical_strategy = TacticalStrategy()
        player.set_strategy(tactical_strategy)
        player.execute_strategy()
        self.assertEqual(player.attributes["klugheit"], 70)  # Klugheit sollte um 20 erhöht sein
        self.assertEqual(player.attributes["mut"], 80)  # Mut sollte um 10 erhöht sein

if __name__ == '__main__':
    unittest.main()