import random
from colorama import Fore, Back, Style, init

# Initialisieren Sie colorama
init(autoreset=True)

# Zustandsklassen für den Spielercharakter
class PlayerState:
    def apply_state(self, player):
        pass

class NormalState(PlayerState):
    def apply_state(self, player):
        player.attributes["mut"] = 50
        player.attributes["klugheit"] = 50
        player.attributes["stärke"] = 50
        player.attributes["magie"] = 50

class StrongState(PlayerState):
    def apply_state(self, player):
        player.attributes["mut"] = 60
        player.attributes["klugheit"] = 50
        player.attributes["stärke"] = 70
        player.attributes["magie"] = 50

class MagicalState(PlayerState):
    def apply_state(self, player):
        player.attributes["mut"] = 50
        player.attributes["klugheit"] = 60
        player.attributes["stärke"] = 50
        player.attributes["magie"] = 70

# Strategieklassen für den Spielercharakter
class PlayerStrategy:
    def execute(self, player):
        pass

class AttackStrategy(PlayerStrategy):
    def execute(self, player):
        player.attributes["mut"] += 20
        player.attributes["stärke"] += 10

class TacticalStrategy(PlayerStrategy):
    def execute(self, player):
        player.attributes["klugheit"] += 20
        player.attributes["mut"] += 10

class MagicStrategy(PlayerStrategy):
    def execute(self, player):
        player.attributes["magie"] += 20
        player.attributes["klugheit"] += 10

# Spielerklasse
class Player:
    def __init__(self, name):
        self.attributes = {
            "name": name,
            "mut": 50,
            "klugheit": 50,
            "stärke": 50,
            "magie": 50
        }
        self.current_state = NormalState()
        self.current_strategy = None

    def set_state(self, state):
        self.current_state = state
        self.current_state.apply_state(self)

    def set_strategy(self, strategy):
        self.current_strategy = strategy

    def execute_strategy(self):
        if self.current_strategy:
            self.current_strategy.execute(self)

# Setup
yes_no = ["yes", "no"]

# Introduction
name = input(Fore.GREEN + "What is your name, adventurer?\n")
print(Fore.YELLOW + "Greetings, " + name + ". Let us embark on a quest!")
print(Fore.YELLOW + "You find yourself at the entrance of the mysterious Mist Kingdom.")
print(Fore.YELLOW + "Will you accept the challenge to unveil its secrets?\n")

# Spieler erstellen
player = Player(name)

# Game functions
def increase_attribute(attribute, amount):
    player.attributes[attribute] += amount

def choose_option(prompt, options):
    while True:
        print(Fore.CYAN + prompt)
        for i, option in enumerate(options, start=1):
            print(f"{Fore.YELLOW}{i}. {option['text']}")
        choice = input(Fore.CYAN + "Enter the number of your choice: ")
        if choice.isdigit() and 1 <= int(choice) <= len(options):
            return int(choice) - 1
        else:
            print(Fore.RED + "Invalid choice. Please select a valid option.")

def show_consequences(consequence_text):
    print(Fore.MAGENTA + "\nConsequence:")
    print(consequence_text)

# Game tasks
tasks = [
    {
        "description": "The journey begins: You reach the entrance of the Mist Kingdom and are greeted by a mysterious stranger. They explain that you possess a unique ability to penetrate the mist. Before you can reach the heart of the kingdom, you must pass three trials.",
        "options": [
            {"text": "I am ready to face the trials.", "mut": +10, "klugheit": +5, "stärke": +5,
             "consequence": "You bravely accept the challenge and gain confidence."},
            {"text": "I doubt my abilities.", "mut": -10, "klugheit": +10,
             "consequence": "You doubt yourself, but your intelligence increases as you contemplate your actions."},
            {"text": "I'll try to deceive the stranger.", "klugheit": +20, "mut": +10,
             "consequence": "You attempt to deceive the stranger, and your intelligence and cunning improve."}
        ]
    },
    {
        "description": "The Trials of the Misty Forest: In the Misty Forest, Elara must confront dangerous creatures and plants to find a magical artifact. How would you like to proceed?",
        "options": [
            {"text": "Bravely attack.", "mut": +20, "stärke": +10,
             "consequence": "You bravely attack and prove your courage, gaining strength."},
            {"text": "Apply clever tactics.", "klugheit": +20, "mut": +10,
             "consequence": "You apply clever tactics, enhancing both your intelligence and cunning."},
            {"text": "Utilize magical abilities.", "magie": +20, "klugheit": +10,
             "consequence": "You harness your magical abilities, improving your magic and intelligence."}
        ]
    },
    {
        "description": "The Enigma of the Mist City: In the Mist City, Elara must solve complex puzzles and navigate labyrinthine paths to unveil the kingdom's history. How would you like to proceed?",
        "options": [
            {"text": "Solve puzzles with intelligence.", "klugheit": +20, "magie": +10,
             "consequence": "You solve puzzles with intelligence, enhancing both your intelligence and magic."},
            {"text": "Use hidden magical clues.", "magie": +20, "klugheit": +10,
             "consequence": "You utilize hidden magical clues, improving both your magic and intelligence."},
            {"text": "Seek assistance from spirits.", "mut": +20, "magie": +10,
             "consequence": "You seek assistance from spirits, gaining mut and enhancing your magic."}
        ]
    },
    {
        "description": "The Storm of the Misty Mountains: Elara faces a raging mist storm in the Misty Mountains, which she must overcome. How would you like to proceed?",
        "options": [
            {"text": "Fight through the storm.", "mut": +20, "stärke": +10,
             "consequence": "You fight through the storm, gaining mut and strength."},
            {"text": "Use magic to calm the storm.", "magie": +20, "klugheit": +10,
             "consequence": "You use magic to calm the storm, enhancing your magic and intelligence."},
            {"text": "Search for a secret path through the storm.", "klugheit": +20, "mut": +10,
             "consequence": "You find a secret path through the storm, improving your intelligence and mut."}
        ]
    },
    {
        "description": "The Temple of Shadows: In the dark ruins of an ancient temple, you must find a lost treasure chest. How would you like to proceed?",
        "options": [
            {"text": "Disappear into the shadows and move silently.", "mut": +20, "magie": +10,
             "consequence": "You disappear into the shadows, gaining mut and enhancing your magic."},
            {"text": "Cast a light spell to dispel shadow creatures.", "magie": +20, "klugheit": +10,
             "consequence": "You cast a light spell to dispel shadow creatures, improving your magic and intelligence."},
            {"text": "Cleverly seize the treasure chest.", "klugheit": +20, "stärke": +10,
             "consequence": "You cleverly seize the treasure chest, enhancing your intelligence and strength."}
        ]
    },
    {
        "description": "The Challenge of the Mist Lord: Finally, you reach the heart of the Mist Kingdom and encounter the mighty Mist Lord, who guards the kingdom's secret. How would you like to proceed?",
        "options": [
            {"text": "Speak with respect and reverence.", "mut": +20, "klugheit": +10,
             "consequence": "You speak with respect and reverence, gaining mut and enhancing your intelligence."},
            {"text": "Impress with your knowledge of the Mist Kingdom.", "klugheit": +20, "magie": +10,
             "consequence": "You impress with your knowledge, improving your intelligence and magic."},
            {"text": "Accept a magical challenge to earn trust.", "magie": +20, "stärke": +10,
             "consequence": "You accept a magical challenge and gain trust, enhancing your magic and strength."}
        ]
    }
]

# Game loop
for task_num, task in enumerate(tasks, start=1):
    print(Fore.GREEN + f"\nTask {task_num}:")
    print(Fore.YELLOW + task["description"])

    option_num = choose_option(Fore.CYAN + "How do you wish to proceed?", task["options"])
    selected_option = task["options"][option_num]

    for attribute, value in selected_option.items():
        if attribute != "text" and attribute != "consequence":
            if value < 0:
                print(Fore.RED + "You made a wrong decision and lose some life.")
                # Implement your life system logic here
            increase_attribute(attribute, value)

    show_consequences(Fore.MAGENTA + selected_option["consequence"])

# Game end
print(Fore.GREEN + "\nGame Over!")
print(Fore.YELLOW + f"{player.attributes['name']}'s Attributes:")
print(Fore.CYAN + f"Mut: {player.attributes['mut']}")
print(f"Klugheit: {player.attributes['klugheit']}")
print(f"Stärke: {player.attributes['stärke']}")
print(f"Magie: {player.attributes['magie']}")

